The examples in this folder are for Code Composer Studio V4

For Code Composer Studio V3.3, please look in the examples folder.