The examples in this folder are for Code Composer Studio V3.3

For Code Composer Studio V4, please look in the examples_ccsv4 folder.