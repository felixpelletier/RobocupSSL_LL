This gel file is legacy information.  

It was useful for old versions of Code Composer Studio that did not directly support 
IQmath types.  It is here for reference in case someone finds it useful.