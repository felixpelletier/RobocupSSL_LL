If the boot ROM symbols needed for a given device are not in this directory,
then please check the boot ROM release for the particular device.

Note: not all devices have IQmath functions within the boot ROM.

controlSUITE\libs\utilities\boot_rom